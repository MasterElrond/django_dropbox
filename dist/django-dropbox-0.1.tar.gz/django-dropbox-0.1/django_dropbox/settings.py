import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DJANGO_DROPBOX_DIR = os.path.join(BASE_DIR, 'django_dropbox')

SECRET_KEY = 'jc49u7mi(p6$*=%g%gpuiuvtm=gaz(#!$p57%_hp4xk&(5nnx5'

DEBUG = True
