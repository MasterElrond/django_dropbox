from django.apps import AppConfig


class DropboxConfig(AppConfig):
    name = 'django_dropbox'
